import { ValidationError } from '../errors.js';

export interface CreateOrderItemInput {
  menuItemId: string;
  quantity: number;
  notes?: string;
}

export interface CreateOrderInput {
  sessionId: string;
  tableId: string;
  items: CreateOrderItemInput[];
}

/**
 * Validates incoming order creation payload.
 */
export function validateCreateOrder(input: unknown): CreateOrderInput {
  if (!input || typeof input !== 'object') {
    throw new ValidationError('Payload must be an object.');
  }

  const { sessionId, tableId, items } = input as Record<string, unknown>;

  if (typeof sessionId !== 'string' || !sessionId.trim()) {
    throw new ValidationError('sessionId is required and must be a string.');
  }

  if (typeof tableId !== 'string' || !tableId.trim()) {
    throw new ValidationError('tableId is required and must be a string.');
  }

  if (!Array.isArray(items) || items.length === 0) {
    throw new ValidationError('items must be a non-empty array.');
  }

  const validatedItems: CreateOrderItemInput[] = items.map((item, index) => {
    if (!item || typeof item !== 'object') {
      throw new ValidationError(`Item at index ${index} must be an object.`);
    }

    const { menuItemId, quantity, notes } = item as Record<string, unknown>;

    if (typeof menuItemId !== 'string' || !menuItemId.trim()) {
      throw new ValidationError(`Item at index ${index} requires a valid menuItemId.`);
    }

    if (typeof quantity !== 'number' || quantity <= 0 || !Number.isInteger(quantity)) {
      throw new ValidationError(`Item at index ${index} must have a positive integer quantity.`);
    }

    return {
      menuItemId: menuItemId.trim(),
      quantity,
      ...(typeof notes === 'string' ? { notes: notes.trim() } : {}),
    };
  });

  return {
    sessionId: sessionId.trim(),
    tableId: tableId.trim(),
    items: validatedItems,
  };
}