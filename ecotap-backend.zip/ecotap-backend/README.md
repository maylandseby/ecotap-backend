# Eco Tap

QR bill splitting and mobile money payments for restaurants, cafes, pubs, grills and bars.

## Folders
- apps/customer-web: customer site (Next.js + Tailwind), Team B
- apps/merchant-pwa: staff PWA (React), Team B
- apps/api: backend (Node/Express/TypeScript), Teams A, C, D
- docs: architecture and planning docs

## Team rules
1. Never push directly to main.
2. Create a branch for every task: feature/short-name (e.g. feature/momo-checkout).
3. Open a Pull Request into main when done.
4. Someone else must review and approve before merging.
5. Pull the latest main before starting a new branch.
6. Never commit secrets. API keys and database URLs go in a local .env file (it is gitignored). Share only .env.example with blank values.
7. Write clear commit messages, e.g. "Add MTN MoMo payment request".

## Who owns what
- Team A: Backend and database
- Team B: Customer and merchant frontends
- Team C: AI chatbot
- Team D: Payments and real-time (MTN MoMo, Airtel Money, Socket.io, Redis)

